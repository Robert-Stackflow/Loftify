import os
import shutil
from PIL import Image


def classify(
    files_path,
    output_path="./classfied/",
    square=True,
    min_size=24,
    max_size=1024,
    size_list=[12, 24, 36, 48, 56, 64, 72, 84, 96, 100, 128, 256, 512, 1024],
    pass_list=["./category.py"],
):
    files_list = os.listdir(files_path)

    for filename in files_list:

        absolute_path = os.path.join(files_path, filename)

        if os.path.isdir(absolute_path):
            continue
        else:
            if absolute_path in pass_list:
                continue

            img = Image.open(absolute_path)

            width = img.size[0]
            height = img.size[1]

            if square:
                if width != height:
                    continue
                if width < min_size or width > max_size:
                    continue
                if len(size_list) > 0 and width not in size_list:
                    continue

            name_path = str(width) + "-" + str(height)
            new_path = os.path.join(output_path, name_path)
            if not os.path.isdir(output_path):
                os.mkdir(output_path)
            if not os.path.isdir(new_path):
                os.mkdir(new_path)
            shutil.copyfile(absolute_path, os.path.join(new_path, filename))


if __name__ == "__main__":
    classify("./png/")
