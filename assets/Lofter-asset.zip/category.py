# coding=utf-8

"""
功能：按图片的尺寸大小进行分类，将尺寸大小相同的图片放在一个新文件夹当中
不同于"按图片尺寸分类.py",本项目定义了一个可以实现分类的函数，给函数路径即可实现分类
"""

import os
import shutil
from PIL import Image



#定义一个分类函数，函数括号中为需要分类的图片文件夹路径
def photo_classify(files_path):
    # 读取文件夹中所有文件的名称
    files_list = os.listdir(files_path)

    # 循环文件夹中的所有文件
    for photo in files_list:

        # 获取图片的绝对路径
        photo_abspath = os.path.join(files_path, photo)
        print(photo_abspath)

        # 判断photo是不是文件夹，若是文件夹则跳过，若不是文件夹则继续执行
        if os.path.isdir(photo_abspath):
            continue
        else:
            print(photo_abspath)
            if photo_abspath == './category.py':
                continue
            # 读图片的尺寸
            img = Image.open(photo_abspath)

            weight = img.size[0]
            high = img.size[1]

            print(weight)
            print(high)

            # 判断新文件夹是否存在，若不存在，则新建文件夹，若存在，则将图片复制到文件夹中
            # 先定义新文件的路径,名字是new_path
            name_path = str(weight) + '-' + str(high)
            print(name_path)
            new_path = os.path.join(files_path, name_path)
            print(new_path)
            # 查询新文件路径下面是否是文件夹
            if os.path.isdir(new_path):
                # 将图片复制到新闻家当中
                shutil.copyfile(photo_abspath, os.path.join(new_path, photo))
                # shutil.copyfile(photo_abspath, new_path)
            else:
                os.mkdir(new_path)
                shutil.copyfile(photo_abspath, os.path.join(new_path, photo))
                # shutil.copyfile(photo_abspath, new_path)
        print('分类成功！')

files_path = './'


if __name__ == '__main__':
    photo_classify(files_path)

